qemu-system-arm -M lm3s811evb -nographic -kernel gcc/RTOSDemo.bin


