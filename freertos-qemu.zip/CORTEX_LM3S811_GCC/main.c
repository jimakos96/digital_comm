


/* Environment includes. */
#include "DriverLib.h"

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"


/* Demo task priorities. */
#define mainCONSOLE_TASK_PRIORITY                ( tskIDLE_PRIORITY + 3 )

/* UART configuration - note this does not use the FIFO so is not very
efficient. */
#define mainBAUD_RATE                ( 19200 )
#define mainFIFO_SET                ( 0x10 )

/* Demo board specifics. */
#define mainPUSH_BUTTON             GPIO_PIN_4

/* Misc. */
#define mainQUEUE_SIZE                ( 3 )
#define mainDEBOUNCE_DELAY            ( ( TickType_t ) 150 / portTICK_PERIOD_MS )
#define mainNO_DELAY                ( ( TickType_t ) 0 )
/*
 * Configure the processor and peripherals for this demo.
 */
static void prvSetupHardware( void );

static void MyTask1( void *pvParameter );

static void MyTask2( void *pvParameter );

static void MyTask3( void *pvParameter );
/* String that is transmitted on the UART. */
static char *cMessage = "Task woken by button interrupt! --- ";
static volatile char *pcNextChar;

/*-----------------------------------------------------------*/

#define UART0BASE ((volatile int*) 0x4000C000)

int putchar (int c){
    (*UART0BASE) = c;
    return c;
}

int puts(const char *s) {
    while (*s) {
        putchar(*s);
        s++;
    }
    return putchar('\n');
}
int main( void )
{
    
    
    puts("Hello, World! puts function is working.");
    /* Configure the clocks, UART and GPIO. */
    prvSetupHardware();

    /* Start the scheduler. */
    
    xTaskCreate(MyTask1, "Task1", 100, NULL, 2, NULL);
    xTaskCreate(MyTask2, "Task2", 100, NULL, 2, NULL);
    xTaskCreate(MyTask3, "Task3", 100, NULL, 5, NULL);
    vTaskStartScheduler();

    /* Will only get here if there was insufficient heap to start the
    scheduler. */

    while(1){
        
    }
    return 0;
}
/*-----------------------------------------------------------*/

static void prvSetupHardware( void )
{
    /* Setup the PLL. */
    SysCtlClockSet( SYSCTL_SYSDIV_10 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN | SYSCTL_XTAL_6MHZ );

    /* Setup the push button. */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);
    GPIODirModeSet(GPIO_PORTC_BASE, mainPUSH_BUTTON, GPIO_DIR_MODE_IN);
    GPIOIntTypeSet( GPIO_PORTC_BASE, mainPUSH_BUTTON,GPIO_FALLING_EDGE );
    IntPrioritySet( INT_GPIOC, configKERNEL_INTERRUPT_PRIORITY );
    GPIOPinIntEnable( GPIO_PORTC_BASE, mainPUSH_BUTTON );
    IntEnable( INT_GPIOC );



    /* Enable the UART.  */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    /* Set GPIO A0 and A1 as peripheral function.  They are used to output the
    UART signals. */
    GPIODirModeSet( GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1, GPIO_DIR_MODE_HW );

    /* Configure the UART for 8-N-1 operation. */
    UARTConfigSet( UART0_BASE, mainBAUD_RATE, UART_CONFIG_WLEN_8 | UART_CONFIG_PAR_NONE | UART_CONFIG_STOP_ONE );

    /* Initialise the LCD> */
    // OSRAMInit(false);
    // OSRAMStringDraw("www.FreeRTOS.org", 0, 0);
    // OSRAMStringDraw("LM3S811 demo", 16, 1);
}
/*-----------------------------------------------------------*/


/*-----------------------------------------------------------*/
void vGPIO_ISR( void )
{
portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;

    /* Clear the interrupt. */
    GPIOPinIntClear(GPIO_PORTC_BASE, mainPUSH_BUTTON);

    /* Wake the button handler task. */
    //xSemaphoreGiveFromISR( xButtonSemaphore, &xHigherPriorityTaskWoken );

    portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
}
/*-----------------------------------------------------------*/

static void MyTask1( void *pvParameters )
{

    for( ;; )
    {
        puts("task1");
        vTaskDelay(300);

    }
}

static void MyTask2( void *pvParameters )
{

    for( ;; )
    {
        puts("task2");
        vTaskDelay(100);
    }
}

static void MyTask3( void *pvParameters )
{
    int i=0;
    TickType_t xLastWakeTime;
    const TickType_t xDelay250ms = pdMS_TO_TICKS( 250 );
    
    for( ;; )
    {
        puts("mmmmmmmmmmmmmmmmmmmmmmmmm");
        vTaskDelay(50);
    }
}
