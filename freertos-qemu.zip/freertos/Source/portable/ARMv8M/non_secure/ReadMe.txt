This directory tree contains the master copy of the FreeeRTOS Cortex-M33 port.
Do not use the files located here!  These file are copied into separate
FreeRTOS/Source/portable/[compiler]/ARM_CM33_NNN directories prior to each
FreeRTOS release.

If your Cortex-M33 application uses TrustZone then use the files from the
FreeRTOS/Source/portable/[compiler]/ARM_CM33 directories.

If your Cortex-M33 application does not use TrustZone then use the files from
the FreeRTOS/Source/portable/[compiler]/ARM_CM33_NTZ directories.

